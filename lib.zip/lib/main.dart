import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:hive_flutter/hive_flutter.dart';
import 'package:nsd_ocr/core/data/app_repository.dart';
import 'package:nsd_ocr/core/data/seed_data.dart';
import 'package:nsd_ocr/core/di/injection.dart';
import 'package:nsd_ocr/core/hive/hive_boxes.dart';
import 'package:nsd_ocr/features/auth/models/user_profile.dart';
import 'package:nsd_ocr/features/chat/models/chat_models.dart';
import 'package:nsd_ocr/features/home/bloc/homepage_bloc.dart';
import 'package:nsd_ocr/features/listing/models/book_listing.dart';
import 'package:nsd_ocr/features/listing/models/listing_draft.dart';
import 'package:nsd_ocr/features/notifications/models/app_notification.dart';
import 'package:nsd_ocr/features/profile/bloc/profile_bloc.dart';
import 'package:nsd_ocr/features/search/models/search_models.dart';
import 'package:nsd_ocr/features/settings/bloc/settings_bloc.dart';
import 'package:nsd_ocr/features/splash/splash_page.dart';
import 'package:nsd_ocr/features/wishlist/bloc/wishlist_bloc.dart';
import 'package:nsd_ocr/features/wishlist/models/wishlist_item.dart';
import 'package:nsd_ocr/utils/app_theme.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Hive.initFlutter();
  _registerAdapters();
  await _openBoxes();
  setupDependencies();
  await _seedIfNeeded(getIt<AppRepository>());
  runApp(const MyApp());
}

void _registerAdapters() {
  Hive
    ..registerAdapter(UserProfileAdapter())
    ..registerAdapter(BookListingAdapter())
    ..registerAdapter(ListingDraftAdapter())
    ..registerAdapter(ChatMessageAdapter())
    ..registerAdapter(ChatThreadAdapter())
    ..registerAdapter(AppNotificationAdapter())
    ..registerAdapter(WishlistItemAdapter())
    ..registerAdapter(SearchHistoryItemAdapter())
    ..registerAdapter(RecentlyViewedItemAdapter());
}

Future<void> _openBoxes() async {
  await Future.wait([
    Hive.openBox<UserProfile>(HiveBoxes.userProfile),
    Hive.openBox<BookListing>(HiveBoxes.listings),
    Hive.openBox<ListingDraft>(HiveBoxes.drafts),
    Hive.openBox<WishlistItem>(HiveBoxes.wishlist),
    Hive.openBox<ChatThread>(HiveBoxes.threads),
    Hive.openBox<AppNotification>(HiveBoxes.notifications),
    Hive.openBox<SearchHistoryItem>(HiveBoxes.recentSearches),
    Hive.openBox<RecentlyViewedItem>(HiveBoxes.recentlyViewed),
    Hive.openBox(HiveBoxes.appPrefs),
  ]);
}

Future<void> _seedIfNeeded(AppRepository repo) async {
  final seeded = await repo.getBoolPref('seeded');
  if (seeded) return;
  for (final listing in SeedData.listings()) {
    await repo.saveListing(listing);
  }
  for (final thread in SeedData.threads()) {
    await repo.saveThread(thread);
  }
  for (final notification in SeedData.notifications()) {
    await repo.saveNotification(notification);
  }
  await repo.saveProfile(SeedData.guestProfile());
  await repo.setBoolPref('seeded', true);
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MultiBlocProvider(
      providers: [
        BlocProvider(create: (_) => HomepageBloc(getIt<AppRepository>())..add(LoadHomepage())),
        BlocProvider(create: (_) => WishlistBloc(getIt<AppRepository>())..add(LoadWishlist())),
        BlocProvider(create: (_) => ProfileBloc(getIt<AppRepository>())..add(LoadProfile())),
        BlocProvider(create: (_) => SettingsBloc(getIt<AppRepository>())..add(LoadSettings())),
      ],
      child: BlocBuilder<SettingsBloc, SettingsState>(
        builder: (context, settingsState) => MaterialApp(
          debugShowCheckedModeBanner: false,
          title: 'BookLoop',
          theme: AppTheme.lightTheme,
          darkTheme: AppTheme.darkTheme,
          themeMode: settingsState.themeMode,
          builder: (context, child) => GestureDetector(
            behavior: HitTestBehavior.translucent,
            onTap: () => FocusManager.instance.primaryFocus?.unfocus(),
            child: child,
          ),
          home: const SplashPage(),
        ),
      ),
    );
  }
}
