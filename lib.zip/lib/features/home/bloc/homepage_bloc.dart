import 'package:equatable/equatable.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:nsd_ocr/core/data/app_repository.dart';

import '../../listing/models/book_listing.dart';
part 'homepage_event.dart';
part 'homepage_state.dart';

class HomepageBloc extends Bloc<HomepageEvent, HomepageState> {
  HomepageBloc(this.repo) : super(const HomepageState()) {
    on<LoadHomepage>(_load);
    on<SelectCategory>(_category);
  }
  final AppRepository repo;

  Future<void> _load(LoadHomepage event, Emitter<HomepageState> emit) async {
    final listings = await repo.listings();
    emit(state.copyWith(loading: false, listings: listings));
  }

  Future<void> _category(SelectCategory event, Emitter<HomepageState> emit) async {
    final all = await repo.listings();
    final filtered = event.category == 'All' ? all : all.where((e) => e.category == event.category).toList();
    emit(state.copyWith(selectedCategory: event.category, listings: filtered));
  }
}
