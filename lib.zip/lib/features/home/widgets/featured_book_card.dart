import 'package:flutter/material.dart';
import 'package:nsd_ocr/features/listing/models/book_listing.dart';

class FeaturedBookCard extends StatelessWidget {
  const FeaturedBookCard({super.key, required this.listing, required this.onTap});
  final BookListing listing;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      child: Container(
        width: 220,
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(16)),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          const Expanded(child: Center(child: Icon(Icons.menu_book, size: 40))),
          Text(listing.title, maxLines: 1, overflow: TextOverflow.ellipsis),
          Text('₹${listing.sellingPrice.toStringAsFixed(0)}'),
        ]),
      ),
    );
  }
}
