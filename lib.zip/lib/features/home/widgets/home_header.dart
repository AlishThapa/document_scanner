import 'package:flutter/material.dart';
import 'package:nsd_ocr/constants/font_sizes.dart';

class HomeHeader extends StatelessWidget {
  const HomeHeader({super.key, required this.name, required this.onNotifications});
  final String name;
  final VoidCallback onNotifications;

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('Hello, $name', style: const TextStyle(fontSize: FontSizes.xl, fontWeight: FontWeight.w700)),
              const SizedBox(height: 2),
              const Text('Find your next thrift read', style: TextStyle(fontSize: FontSizes.sm)),
            ],
          ),
        ),
        IconButton(onPressed: onNotifications, icon: const Icon(Icons.notifications_none_rounded)),
      ],
    );
  }
}
