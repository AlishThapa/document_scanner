import 'package:nsd_ocr/features/listing/models/book_listing.dart';

typedef HomeBookModel = BookListing;
