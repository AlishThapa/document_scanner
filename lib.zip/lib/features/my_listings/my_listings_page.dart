import 'package:flutter/material.dart';
import 'package:nsd_ocr/constants/design_tokens.dart';
import 'package:nsd_ocr/constants/widgets/app_surface.dart';
import 'package:nsd_ocr/core/data/app_repository.dart';
import 'package:nsd_ocr/core/di/injection.dart';
import 'package:nsd_ocr/features/home/homepage.dart';
import 'package:nsd_ocr/shared/widgets/book_card.dart';

class MyListingsPage extends StatelessWidget {
  const MyListingsPage({super.key});

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 3,
      child: Scaffold(
        appBar: AppBar(title: const Text('My Listings'), bottom: const TabBar(tabs: [Tab(text: 'Active'), Tab(text: 'Sold'), Tab(text: 'Drafts')])),
        body: FutureBuilder(
          future: getIt<AppRepository>().listings(),
          builder: (_, snapshot) {
            final all = snapshot.data ?? [];
            return TabBarView(children: [
              ListView.separated(
                padding: const EdgeInsets.all(AppSpacing.md),
                itemCount: all.where((e) => e.status == 'active').length,
                separatorBuilder: (_, __) => const SizedBox(height: AppSpacing.xs),
                itemBuilder: (_, i) => BookCard(listing: all.where((e) => e.status == 'active').toList()[i]),
              ),
              ListView.separated(
                padding: const EdgeInsets.all(AppSpacing.md),
                itemCount: all.where((e) => e.status == 'sold').length,
                separatorBuilder: (_, __) => const SizedBox(height: AppSpacing.xs),
                itemBuilder: (_, i) => BookCard(listing: all.where((e) => e.status == 'sold').toList()[i]),
              ),
              FutureBuilder(
                future: getIt<AppRepository>().drafts(),
                builder: (_, s) {
                  final drafts = s.data ?? [];
                  if (drafts.isEmpty) return const Center(child: Text('No drafts yet'));
                  return ListView(
                    padding: const EdgeInsets.all(AppSpacing.md),
                    children: drafts
                        .map(
                          (e) => AppSurface(
                            margin: const EdgeInsets.only(bottom: AppSpacing.xs),
                            child: ListTile(
                              contentPadding: EdgeInsets.zero,
                              title: Text(e.data['title']?.toString() ?? 'Untitled Draft', style: AppTextStyles.cardTitle),
                              subtitle: Text('Updated ${e.updatedAt}', style: AppTextStyles.caption),
                              trailing: const Icon(Icons.arrow_forward_ios_rounded, size: 16),
                              onTap: () => Navigator.pushAndRemoveUntil(
                                context,
                                MaterialPageRoute(builder: (_) => MainShellPage(initialIndex: 2, initialDraft: e)),
                                (_) => false,
                              ),
                            ),
                          ),
                        )
                        .toList(),
                  );
                },
              ),
            ]);
          },
        ),
      ),
    );
  }
}
