import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:nsd_ocr/constants/design_tokens.dart';
import 'package:nsd_ocr/core/data/app_repository.dart';
import 'package:nsd_ocr/core/di/injection.dart';
import 'package:nsd_ocr/features/listing/book_detail_page.dart';
import 'package:nsd_ocr/features/search/bloc/search_bloc.dart';
import 'package:nsd_ocr/shared/widgets/book_card.dart';
import 'package:nsd_ocr/shared/widgets/system/app_filter_chip.dart';
import 'package:nsd_ocr/shared/widgets/system/app_search_bar.dart';

class SearchPage extends StatelessWidget {
  const SearchPage({super.key});

  @override
  Widget build(BuildContext context) {
    return BlocProvider(
      create: (_) => SearchBloc(getIt<AppRepository>())..add(LoadSearch()),
      child: const _SearchView(),
    );
  }
}

class _SearchView extends StatefulWidget {
  const _SearchView();

  @override
  State<_SearchView> createState() => _SearchViewState();
}

class _SearchViewState extends State<_SearchView> {
  String? selectedChip;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Search Books')),
      body: BlocBuilder<SearchBloc, SearchState>(
        builder: (context, state) {
          final categories = ['Engineering', 'School', 'Medical', 'Business'];
          final results = selectedChip == null ? state.results : state.results.where((e) => e.category.toLowerCase().contains(selectedChip!.toLowerCase())).toList();

          return Padding(
            padding: const EdgeInsets.symmetric(horizontal: AppSpacing.md),
            child: Column(
              children: [
                const SizedBox(height: AppSpacing.xs),
                AppSearchBar(
                  hintText: 'Title, author, course, institution...',
                  showFilterIcon: true,
                  onChanged: (v) => context.read<SearchBloc>().add(QueryChanged(v)),
                ),
                const SizedBox(height: AppSpacing.xs),
                SingleChildScrollView(
                  scrollDirection: Axis.horizontal,
                  child: Row(
                    children: [
                      for (final c in categories)
                        Padding(
                          padding: const EdgeInsets.only(right: AppSpacing.xs),
                          child: AppFilterChip(
                            label: c,
                            selected: selectedChip == c,
                            onSelected: (_) => setState(() => selectedChip = selectedChip == c ? null : c),
                          ),
                        ),
                    ],
                  ),
                ),
                if (state.recent.isNotEmpty)
                  Padding(
                    padding: const EdgeInsets.symmetric(vertical: AppSpacing.xs),
                    child: Wrap(
                      spacing: 6,
                      children: state.recent
                          .take(6)
                          .map((e) => InputChip(label: Text(e.query), onPressed: () => context.read<SearchBloc>().add(QueryChanged(e.query))))
                          .toList(),
                    ),
                  ),
                Expanded(
                  child: state.query.trim().isEmpty
                      ? const Center(child: Text('Search for books'))
                      : ListView.separated(
                          itemCount: results.length,
                          separatorBuilder: (_, __) => const SizedBox(height: AppSpacing.xs),
                          itemBuilder: (_, i) => BookCard(
                            listing: results[i],
                            onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => BookDetailPage(listing: results[i]))),
                          ),
                        ),
                ),
              ],
            ),
          );
        },
      ),
    );
  }
}
