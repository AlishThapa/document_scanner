import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:nsd_ocr/constants/design_tokens.dart';
import 'package:nsd_ocr/constants/widgets/app_surface.dart';
import 'package:nsd_ocr/features/chat/chat_detail_page.dart';
import 'package:nsd_ocr/features/listing/models/book_listing.dart';
import 'package:nsd_ocr/features/wishlist/bloc/wishlist_bloc.dart';
import 'package:nsd_ocr/shared/widgets/system/app_buttons.dart';
import 'package:nsd_ocr/shared/widgets/system/bottom_cta_bar.dart';
import 'package:nsd_ocr/shared/widgets/system/info_row.dart';

class BookDetailPage extends StatelessWidget {
  const BookDetailPage({super.key, required this.listing});
  final BookListing listing;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Book Details'),
        actions: [
          BlocBuilder<WishlistBloc, WishlistState>(
            builder: (_, state) {
              final selected = state.ids.contains(listing.id);
              return IconButton(
                onPressed: () => context.read<WishlistBloc>().add(ToggleWishlist(listing.id)),
                icon: Icon(selected ? Icons.favorite : Icons.favorite_border, color: selected ? Colors.red : null),
              );
            },
          ),
        ],
      ),
      bottomNavigationBar: BottomCtaBar(
        children: [
          Expanded(
            child: SecondaryButton(
              label: 'Chat',
              icon: Icons.chat_bubble_outline,
              onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => ChatDetailPage(threadId: 't1', listing: listing))),
            ),
          ),
          const SizedBox(width: AppSpacing.xs),
          Expanded(child: PrimaryButton(label: 'Reserve / Buy', icon: Icons.shopping_bag_outlined, onPressed: () {})),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.all(AppSpacing.md),
        children: [
          AppSurface(
            padding: const EdgeInsets.all(AppSpacing.md),
            child: Container(
              height: 180,
              decoration: BoxDecoration(color: const Color(0xFFEEF2FF), borderRadius: BorderRadius.circular(AppRadius.md)),
              child: const Center(child: Icon(Icons.menu_book_rounded, size: 70)),
            ),
          ),
          const SizedBox(height: AppSpacing.sm),
          Text(listing.title, style: AppTextStyles.largeHeading),
          Text('by ${listing.author}', style: AppTextStyles.subtitle),
          const SizedBox(height: AppSpacing.xs),
          Text('₹${listing.sellingPrice.toStringAsFixed(0)}', style: AppTextStyles.price.copyWith(fontSize: 24)),
          const SizedBox(height: AppSpacing.sm),
          AppSurface(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text('Book Information', style: AppTextStyles.cardTitle),
                const SizedBox(height: AppSpacing.xs),
                InfoRow(icon: Icons.category_outlined, label: '${listing.category} • ${listing.classOrCourse} • Sem ${listing.semester}'),
                InfoRow(icon: Icons.check_circle_outline, label: 'Condition: ${listing.condition}'),
                InfoRow(icon: Icons.location_on_outlined, label: '${listing.deliveryMethod.join(', ')} at ${listing.location}'),
                InfoRow(icon: Icons.sell_outlined, label: 'Original ₹${listing.originalPrice.toStringAsFixed(0)}'),
              ],
            ),
          ),
          const SizedBox(height: AppSpacing.sm),
          AppSurface(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text('Description', style: AppTextStyles.cardTitle),
                const SizedBox(height: AppSpacing.xs),
                Text(listing.description, style: AppTextStyles.subtitle),
              ],
            ),
          ),
          const SizedBox(height: AppSpacing.sm),
          const AppSurface(
            child: ListTile(
              contentPadding: EdgeInsets.zero,
              leading: CircleAvatar(child: Icon(Icons.person)),
              title: Text('Seller: Local Student', style: AppTextStyles.cardTitle),
              subtitle: Text('Rating 4.6 ★ • 34 reviews', style: AppTextStyles.caption),
            ),
          ),
        ],
      ),
    );
  }
}
