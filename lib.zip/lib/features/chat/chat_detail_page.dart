import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:nsd_ocr/constants/design_tokens.dart';
import 'package:nsd_ocr/constants/widgets/app_surface.dart';
import 'package:nsd_ocr/core/data/app_repository.dart';
import 'package:nsd_ocr/core/di/injection.dart';
import 'package:nsd_ocr/features/chat/bloc/chat_bloc.dart';
import 'package:nsd_ocr/features/listing/models/book_listing.dart';

class ChatDetailPage extends StatefulWidget {
  const ChatDetailPage({super.key, required this.threadId, required this.listing});
  final String threadId;
  final BookListing listing;

  @override
  State<ChatDetailPage> createState() => _ChatDetailPageState();
}

class _ChatDetailPageState extends State<ChatDetailPage> {
  final ctrl = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return BlocProvider(
      create: (_) => ChatBloc(getIt<AppRepository>())..add(LoadThreads()),
      child: Scaffold(
        appBar: AppBar(title: Text(widget.listing.title)),
        body: BlocBuilder<ChatBloc, ChatState>(
          builder: (context, state) {
            final thread = state.threads.where((e) => e.id == widget.threadId).firstOrNull;
            final msgs = thread?.messages ?? [];
            return Column(
              children: [
                Padding(
                  padding: const EdgeInsets.all(AppSpacing.md),
                  child: AppSurface(
                    child: ListTile(
                      contentPadding: EdgeInsets.zero,
                      title: Text(widget.listing.title, style: AppTextStyles.cardTitle),
                      subtitle: Text('₹${widget.listing.sellingPrice}', style: AppTextStyles.price),
                    ),
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: AppSpacing.md),
                  child: Wrap(
                    spacing: AppSpacing.xs,
                    runSpacing: 4,
                    children: ['Is this available?', 'Can you lower the price?', 'Where can we meet?', 'Is delivery possible?']
                        .map((e) => ActionChip(label: Text(e), onPressed: () => context.read<ChatBloc>().add(SendMessage(widget.threadId, e))))
                        .toList(),
                  ),
                ),
                const SizedBox(height: AppSpacing.xs),
                Expanded(
                  child: ListView(
                    padding: const EdgeInsets.symmetric(horizontal: AppSpacing.md),
                    children: msgs
                        .map(
                          (m) => Align(
                            alignment: m.isMe ? Alignment.centerRight : Alignment.centerLeft,
                            child: Container(
                              margin: const EdgeInsets.only(bottom: 6),
                              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
                              decoration: BoxDecoration(
                                color: m.isMe ? const Color(0xFFE0E7FF) : Colors.white,
                                borderRadius: BorderRadius.circular(14),
                                border: Border.all(color: const Color(0xFFE2E8F0)),
                              ),
                              child: Text(m.text),
                            ),
                          ),
                        )
                        .toList(),
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.all(AppSpacing.md),
                  child: Row(
                    children: [
                      Expanded(
                        child: TextField(controller: ctrl, decoration: const InputDecoration(hintText: 'Type a message...')),
                      ),
                      const SizedBox(width: 8),
                      FilledButton(
                        onPressed: () {
                          context.read<ChatBloc>().add(SendMessage(widget.threadId, ctrl.text));
                          ctrl.clear();
                        },
                        child: const Icon(Icons.send_rounded),
                      ),
                    ],
                  ),
                ),
              ],
            );
          },
        ),
      ),
    );
  }
}
