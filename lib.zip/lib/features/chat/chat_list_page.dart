import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:nsd_ocr/constants/design_tokens.dart';
import 'package:nsd_ocr/constants/widgets/app_surface.dart';
import 'package:nsd_ocr/core/data/app_repository.dart';
import 'package:nsd_ocr/core/di/injection.dart';
import 'package:nsd_ocr/features/chat/bloc/chat_bloc.dart';
import 'package:nsd_ocr/features/chat/chat_detail_page.dart';
import 'package:nsd_ocr/features/listing/models/book_listing.dart';

class ChatListPage extends StatelessWidget {
  const ChatListPage({super.key});

  @override
  Widget build(BuildContext context) {
    return BlocProvider(
      create: (_) => ChatBloc(getIt<AppRepository>())..add(LoadThreads()),
      child: Scaffold(
        appBar: AppBar(title: const Text('Chats')),
        body: BlocBuilder<ChatBloc, ChatState>(
          builder: (_, state) {
            return ListView.separated(
              padding: const EdgeInsets.all(AppSpacing.md),
              itemCount: state.threads.length,
              separatorBuilder: (_, __) => const SizedBox(height: AppSpacing.xs),
              itemBuilder: (_, i) {
                final t = state.threads[i];
                return AppSurface(
                  child: ListTile(
                    contentPadding: EdgeInsets.zero,
                    leading: CircleAvatar(child: Text(t.peerName[0])),
                    title: Text(t.peerName, style: AppTextStyles.cardTitle),
                    subtitle: Text(t.messages.isEmpty ? t.bookTitle : t.messages.last.text, maxLines: 1, overflow: TextOverflow.ellipsis, style: AppTextStyles.caption),
                    trailing: const Icon(Icons.chevron_right),
                    onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => ChatDetailPage(threadId: t.id, listing: BookListing.sample(t.bookId, t.bookTitle, 'Unknown', 'General', 20, 10)))),
                  ),
                );
              },
            );
          },
        ),
      ),
    );
  }
}
