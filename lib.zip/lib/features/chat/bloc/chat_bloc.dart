import 'package:equatable/equatable.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:nsd_ocr/core/data/app_repository.dart';

import 'package:nsd_ocr/features/chat/models/chat_models.dart';
part 'chat_event.dart';
part 'chat_state.dart';
class ChatBloc extends Bloc<ChatEvent, ChatState> {
  ChatBloc(this.repo) : super(const ChatState()) { on<LoadThreads>(_load); on<SendMessage>(_send); }
  final AppRepository repo;

  Future<void> _load(LoadThreads e, Emitter<ChatState> emit) async => emit(state.copyWith(threads: await repo.threads()));

  Future<void> _send(SendMessage e, Emitter<ChatState> emit) async {
    final list = [...state.threads];
    final i = list.indexWhere((t) => t.id == e.threadId);
    if (i < 0) return;
    final updated = [...list[i].messages, ChatMessage(id: DateTime.now().toString(), text: e.text, isMe: true, sentAt: DateTime.now())];
    final thread = list[i].copyWith(messages: updated, updatedAt: DateTime.now());
    list[i] = thread;
    await repo.saveThread(thread);
    emit(state.copyWith(threads: list));
  }
}
