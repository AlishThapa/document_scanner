part of 'chat_bloc.dart';

sealed class ChatEvent extends Equatable { const ChatEvent(); @override List<Object?> get props => []; }
class LoadThreads extends ChatEvent {}
class SendMessage extends ChatEvent { const SendMessage(this.threadId, this.text); final String threadId; final String text; @override List<Object?> get props => [threadId, text]; }
