import 'package:hive/hive.dart';
import 'package:nsd_ocr/core/hive/hive_type_ids.dart';

class ChatMessage {
  ChatMessage({required this.id, required this.text, required this.isMe, required this.sentAt});
  final String id;
  final String text;
  final bool isMe;
  final DateTime sentAt;
}

class ChatThread {
  ChatThread({required this.id, required this.bookId, required this.bookTitle, required this.peerName, required this.messages, required this.updatedAt});
  final String id;
  final String bookId;
  final String bookTitle;
  final String peerName;
  final List<ChatMessage> messages;
  final DateTime updatedAt;

  ChatThread copyWith({List<ChatMessage>? messages, DateTime? updatedAt}) => ChatThread(
        id: id, bookId: bookId, bookTitle: bookTitle, peerName: peerName, messages: messages ?? this.messages, updatedAt: updatedAt ?? this.updatedAt,
      );

  static ChatThread sample() => ChatThread(
        id: 't1',
        bookId: '1',
        bookTitle: 'Calculus for Engineers',
        peerName: 'Aditi',
        messages: [
          ChatMessage(id: 'm1', text: 'Is this available?', isMe: true, sentAt: DateTime.now().subtract(const Duration(hours: 2))),
          ChatMessage(id: 'm2', text: 'Yes, available near campus gate.', isMe: false, sentAt: DateTime.now().subtract(const Duration(hours: 1))),
        ],
        updatedAt: DateTime.now(),
      );
}

class ChatMessageAdapter extends TypeAdapter<ChatMessage> {
  @override
  final int typeId = HiveTypeIds.chatMessage;
  @override
  ChatMessage read(BinaryReader r) => ChatMessage(id: r.readString(), text: r.readString(), isMe: r.readBool(), sentAt: DateTime.fromMillisecondsSinceEpoch(r.readInt()));
  @override
  void write(BinaryWriter w, ChatMessage o) => w..writeString(o.id)..writeString(o.text)..writeBool(o.isMe)..writeInt(o.sentAt.millisecondsSinceEpoch);
}

class ChatThreadAdapter extends TypeAdapter<ChatThread> {
  @override
  final int typeId = HiveTypeIds.chatThread;
  @override
  ChatThread read(BinaryReader r) => ChatThread(
      id: r.readString(), bookId: r.readString(), bookTitle: r.readString(), peerName: r.readString(),
      messages: (r.readList()).cast<ChatMessage>(), updatedAt: DateTime.fromMillisecondsSinceEpoch(r.readInt()));
  @override
  void write(BinaryWriter w, ChatThread o) => w..writeString(o.id)..writeString(o.bookId)..writeString(o.bookTitle)..writeString(o.peerName)..writeList(o.messages)..writeInt(o.updatedAt.millisecondsSinceEpoch);
}
