import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:nsd_ocr/constants/design_tokens.dart';
import 'package:nsd_ocr/constants/widgets/app_surface.dart';
import 'package:nsd_ocr/constants/widgets/app_text_form_field.dart';
import 'package:nsd_ocr/core/data/app_repository.dart';
import 'package:nsd_ocr/core/di/injection.dart';
import 'package:nsd_ocr/features/auth/models/user_profile.dart';
import 'package:nsd_ocr/features/my_listings/my_listings_page.dart';
import 'package:nsd_ocr/features/notifications/notifications_page.dart';
import 'package:nsd_ocr/features/profile/bloc/profile_bloc.dart';
import 'package:nsd_ocr/features/profile/public_seller_profile_page.dart';
import 'package:nsd_ocr/features/settings/settings_page.dart';
import 'package:nsd_ocr/features/wishlist/wishlist_page.dart';
import 'package:nsd_ocr/shared/widgets/system/profile_card.dart';

class ProfilePage extends StatelessWidget {
  const ProfilePage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Profile')),
      body: BlocBuilder<ProfileBloc, ProfileState>(
        builder: (_, state) {
          final p = state.profile;
          return ListView(
            padding: const EdgeInsets.all(AppSpacing.md),
            children: [
              ProfileCard(
                name: p?.fullName ?? 'Guest User',
                subtitle: '${p?.institutionName ?? 'Institution'} • ${p?.location ?? 'Location'}',
                meta: '${p?.classOrCourse ?? 'Course'} • ${p?.semesterOrYear ?? 'Year/Semester'}',
                imagePath: p?.imagePath,
                onEdit: () async {
                  await Navigator.push(context, MaterialPageRoute(builder: (_) => EditProfilePage(profile: p)));
                  if (!context.mounted) return;
                  context.read<ProfileBloc>().add(LoadProfile());
                },
              ),
              const SizedBox(height: AppSpacing.sm),
              _tile(context, Icons.inventory_2_outlined, 'My Listings', () => Navigator.push(context, MaterialPageRoute(builder: (_) => const MyListingsPage()))),
              _tile(context, Icons.favorite_border, 'Wishlist', () => Navigator.push(context, MaterialPageRoute(builder: (_) => const WishlistPage()))),
              _tile(context, Icons.notifications_none_rounded, 'Notifications', () => Navigator.push(context, MaterialPageRoute(builder: (_) => const NotificationsPage()))),
              _tile(context, Icons.settings_outlined, 'Settings', () => Navigator.push(context, MaterialPageRoute(builder: (_) => const SettingsPage()))),
              _tile(context, Icons.storefront_outlined, 'Public Seller Profile', () => Navigator.push(context, MaterialPageRoute(builder: (_) => const PublicSellerProfilePage()))),
            ],
          );
        },
      ),
    );
  }

  Widget _tile(BuildContext context, IconData icon, String title, VoidCallback onTap) {
    return AppSurface(
      margin: const EdgeInsets.only(bottom: AppSpacing.xs),
      child: ListTile(
        leading: Icon(icon),
        title: Text(title, style: AppTextStyles.cardTitle),
        subtitle: const Text('Manage this section', style: AppTextStyles.caption),
        trailing: const Icon(Icons.chevron_right),
        onTap: onTap,
        contentPadding: EdgeInsets.zero,
      ),
    );
  }
}

class EditProfilePage extends StatefulWidget {
  const EditProfilePage({super.key, this.profile});
  final UserProfile? profile;

  @override
  State<EditProfilePage> createState() => _EditProfilePageState();
}

class _EditProfilePageState extends State<EditProfilePage> {
  late final TextEditingController imagePath = TextEditingController(text: widget.profile?.imagePath ?? '');
  late final TextEditingController name = TextEditingController(text: widget.profile?.fullName ?? '');
  late final TextEditingController email = TextEditingController(text: widget.profile?.email ?? '');
  late final TextEditingController phone = TextEditingController(text: widget.profile?.phone ?? '');
  late final TextEditingController institution = TextEditingController(text: widget.profile?.institutionName ?? '');
  late final TextEditingController classOrCourse = TextEditingController(text: widget.profile?.classOrCourse ?? '');
  late final TextEditingController yearSemester = TextEditingController(text: widget.profile?.semesterOrYear ?? '');
  late final TextEditingController location = TextEditingController(text: widget.profile?.location ?? '');

  @override
  void dispose() {
    imagePath.dispose();
    name.dispose();
    email.dispose();
    phone.dispose();
    institution.dispose();
    classOrCourse.dispose();
    yearSemester.dispose();
    location.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Edit Profile')),
      body: Padding(
        padding: const EdgeInsets.all(AppSpacing.md),
        child: AppSurface(
          child: SingleChildScrollView(
            child: Column(
              children: [
                AppTextFormField(label: 'Profile image URL', controller: imagePath),
                AppTextFormField(label: 'Full name', controller: name),
                AppTextFormField(label: 'Email', controller: email),
                AppTextFormField(label: 'Phone', controller: phone),
                AppTextFormField(label: 'Institution', controller: institution),
                AppTextFormField(label: 'Class/Course', controller: classOrCourse),
                AppTextFormField(label: 'Year/Semester', controller: yearSemester),
                AppTextFormField(label: 'Location', controller: location),
                const SizedBox(height: AppSpacing.xs),
                SizedBox(
                  width: double.infinity,
                  child: FilledButton(
                    onPressed: () async {
                      await getIt<AppRepository>().saveProfile(UserProfile(
                        fullName: name.text,
                        email: email.text,
                        phone: phone.text,
                        userType: widget.profile?.userType ?? 'reader',
                        institutionName: institution.text,
                        classOrCourse: classOrCourse.text,
                        semesterOrYear: yearSemester.text,
                        location: location.text,
                        imagePath: imagePath.text,
                      ));
                      if (!mounted) return;
                      Navigator.pop(context);
                    },
                    child: const Text('Save changes'),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
