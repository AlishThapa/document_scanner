import 'package:get_it/get_it.dart';
import 'package:nsd_ocr/core/data/app_repository.dart';
import 'package:nsd_ocr/core/data/local_data_source.dart';

final getIt = GetIt.instance;

void setupDependencies() {
  getIt.registerLazySingleton(LocalDataSource.new);
  getIt.registerLazySingleton(() => AppRepository(getIt()));
}
