import 'package:flutter/material.dart';
import 'package:nsd_ocr/constants/design_tokens.dart';
import 'package:nsd_ocr/constants/widgets/app_surface.dart';
import 'package:nsd_ocr/features/listing/models/book_listing.dart';

class BookCard extends StatelessWidget {
  const BookCard({
    super.key,
    required this.listing,
    this.onTap,
    this.trailing,
    this.grid = false,
  });

  final BookListing listing;
  final VoidCallback? onTap;
  final Widget? trailing;
  final bool grid;

  @override
  Widget build(BuildContext context) {
    return grid ? _GridCard(listing: listing, onTap: onTap) : _ListCard(listing: listing, onTap: onTap, trailing: trailing);
  }
}

class _ListCard extends StatelessWidget {
  const _ListCard({required this.listing, this.onTap, this.trailing});
  final BookListing listing;
  final VoidCallback? onTap;
  final Widget? trailing;

  @override
  Widget build(BuildContext context) {
    return AppSurface(
      child: ListTile(
        onTap: onTap,
        contentPadding: EdgeInsets.zero,
        leading: Container(
          width: 54,
          height: 54,
          decoration: BoxDecoration(color: Theme.of(context).colorScheme.primary.withAlpha(28), borderRadius: BorderRadius.circular(AppRadius.sm)),
          child: Center(child: Text(listing.title.substring(0, 1), style: AppTextStyles.sectionTitle)),
        ),
        title: Text(listing.title, maxLines: 1, overflow: TextOverflow.ellipsis, style: AppTextStyles.cardTitle),
        subtitle: Padding(
          padding: const EdgeInsets.only(top: 4),
          child: Text('${listing.author} • ${listing.condition}', style: AppTextStyles.subtitle),
        ),
        trailing: trailing ?? Text('₹${listing.sellingPrice.toStringAsFixed(0)}', style: AppTextStyles.price),
      ),
    );
  }
}

class _GridCard extends StatelessWidget {
  const _GridCard({required this.listing, this.onTap});
  final BookListing listing;
  final VoidCallback? onTap;

  @override
  Widget build(BuildContext context) {
    return InkWell(
      borderRadius: BorderRadius.circular(AppRadius.md),
      onTap: onTap,
      child: AppSurface(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Expanded(
              child: Container(
                width: double.infinity,
                decoration: BoxDecoration(color: Theme.of(context).colorScheme.primary.withAlpha(28), borderRadius: BorderRadius.circular(AppRadius.sm)),
                child: const Icon(Icons.menu_book_rounded, size: 34),
              ),
            ),
            const SizedBox(height: AppSpacing.xs),
            Text(listing.title, maxLines: 1, overflow: TextOverflow.ellipsis, style: AppTextStyles.cardTitle),
            Text(listing.author, maxLines: 1, overflow: TextOverflow.ellipsis, style: AppTextStyles.caption),
            const SizedBox(height: 2),
            Text('₹${listing.sellingPrice.toStringAsFixed(0)}', style: AppTextStyles.price),
          ],
        ),
      ),
    );
  }
}
