import 'package:flutter/material.dart';
import 'package:nsd_ocr/constants/design_tokens.dart';

class BottomCtaBar extends StatelessWidget {
  const BottomCtaBar({super.key, required this.children});

  final List<Widget> children;

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      minimum: const EdgeInsets.all(AppSpacing.md),
      child: Container(
        padding: const EdgeInsets.all(AppSpacing.sm),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(AppRadius.lg),
          border: Border.all(color: const Color(0xFFE2E8F0)),
        ),
        child: Row(children: children),
      ),
    );
  }
}
